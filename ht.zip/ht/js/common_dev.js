var FACEBOOK_APP_ID = '898977593530135';
var GOOGLE_CODE = 'UA-66726230-1'; // UA-66726230-1
var pathname = location.pathname;
    
/* Google Analytics */
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

    ga('create', GOOGLE_CODE, 'auto');
    ga('send', 'pageview');
    
/* End Google Analytics */

$(function() {
    // 스마트 검색
    $("input[name=search]").keyup(function(e) {
        if(e.keyCode == 13) {
            var searchTxt = $(this).val();
            var searchFrm = $("#searchFrm");
            
            if(searchTxt == null || $.trim(searchTxt).length == 0) {
                alert('검색어를 입력해 주세요.');
                return;
            } else {
                $("#totalSearchTxt").val(searchTxt);
                searchFrm.attr('action', '/search');
                searchFrm.attr('method', 'post');
                searchFrm.submit();
            }
        }
    });
    
    
    // 다운로드
    $(".download").click(function() {
        var newFileName = $(this).data('newfilename');
        var oriFileName = $(this).data('orifilename');
        var boardType = $(this).data('boardtype');
        boardType = (boardType == null) ? '' : boardType;
        var filePath = '/'+boardType;
        
        $("input[name=fileOriName]").val(oriFileName);
        $("input[name=fileName]").val(newFileName);
        $("input[name=filePath]").val(filePath);
        $("form[name=downLoadForm]").submit();
    });
    
    
    
    // gnb링크 클릭 이벤트
    $(".header-nav").click(function() {
        var link = $(this).data('link');
        
        if(link == 'about') {
            location.href = '/product/honey';
        } else if(link == 'honeyworld'){
            location.href = '/sweet/cf/view';
        } else if(link == 'event'){
            location.href = '/event/eventList';
        } else if(link == 'customer'){
            location.href = '/customer/faq';
        } else if(link == 'company'){
            location.href = '/introduce/ceo';
        }
    });
    
    
    if(pathname == '/' || pathname == '/main') {
        window.fbAsyncInit = function() {
            FB.init({
              appId      : FACEBOOK_APP_ID,
              xfbml      : true,
              version    : 'v2.4'
            });
          };
          
          (function(d, s, id){
              var js, fjs = d.getElementsByTagName(s)[0];
              if (d.getElementById(id)) return;
              js = d.createElement(s); js.id = id;
              js.src = "//connect.facebook.net/ko_KR/sdk.js";
              fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));
          
          // 페북 피드 가져오기
          $.post(
                  "/getFacebookPageInfo"
                  , function(response) {
                      var noti1 = $("#facebookFeed1");
                      var noti2 = $("#facebookFeed2");
                      
                      var name = response.data.name;
                      var picture = response.data.picture.data.url;
                      
                      var datas = response.data.posts.data;
                      var posts1;
                      var posts2;
                      
                      if(datas.length > 0) {
                          
                          var index = 0;
                          $.each(datas, function(i, data) {
                              if(data.message != null) {
                                  if(index == 0) {
                                      posts1 = data;
                                      index++;
                                  } else {
                                      posts2 = data;
                                      return false;
                                  }
                              }
                          });
                          
                          var link1 = (posts1.link == null) ? 'https://www.facebook.com/HaitaiCo' : posts1.link;
                          var link2 = (posts2.link == null) ? 'https://www.facebook.com/HaitaiCo' : posts2.link;
                          var shareCount1 = (posts1.shares != null) ? posts1.shares.count : 0;
                          var shareCount2 = (posts2.shares != null) ? posts2.shares.count : 0;
                          var shareMsg1 = (posts1.message != null) ? posts1.message : '페이스북 페이지 이동';
                          var shareMsg2 = (posts2.message!= null) ? posts2.message : '페이스북 페이지 이동';
                          
                          if(shareMsg1.length > 150) {
                              shareMsg1 = shareMsg1.substring(0,150) + '.....';
                          }
                          if(shareMsg2.length > 150) {
                              shareMsg2 = shareMsg2.substring(0,150) + '.....';
                          }
                          
                          noti1.find('.HfbName').text(name);
                          noti1.find('img.Hfbthumb').attr('src',picture);
                          noti1.find('a').attr('href', link1);
                          noti1.find('.HfbDate').text(posts1.created_time.substring(0,10));
                          noti1.find('.HfbInfo .like').text(posts1.likes.summary.total_count);
                          noti1.find('.HfbInfo .reply').text(posts1.comments.summary.total_count);
                          noti1.find('.HfbInfo .scrap').text(shareCount1);
                          noti1.find('.HfbTxt').text(shareMsg1);
                          
                          noti2.find('.HfbName').text(name);
                          noti2.find('img.Hfbthumb').attr('src',picture);
                          noti2.find('a').attr('href', link2);
                          noti2.find('.HfbDate').text(posts2.created_time.substring(0,10));
                          noti2.find('.HfbInfo .like').text(posts2.likes.summary.total_count);
                          noti2.find('.HfbInfo .reply').text(posts2.comments.summary.total_count);
                          noti2.find('.HfbInfo .scrap').text(shareCount2);
                          noti2.find('.HfbTxt').text(shareMsg2);
                      }
                  
                  }
          )
    }
});
