var frame = 0, frame1=0, frame2=0,frame3=0,frame4=0,frame5=0,
	balloontween,beestween,cloudtween0,cloudtween1,cloudtween2,
	anibee = $('.beegif.honeybee'),	
	anibee2 = $('.beegif.bee'),
	beeMoving = false, txtmain=false,
	beeMainMoving = false,titTimer0,circlemov=false,
	beeMoving1 = false, titTimer1, titTimer2, titTimer3, mainsettimeout=false;

// Main bee animation
function beegif(){
	if ( beeMainMoving == true ){	
	}
	else{
		var mainbee = $('.mainvisual3'); // , sweetworld = $('.mainvisual9');
		(function enter(){
			titTimer = setTimeout (function(){
				var posY, posS;               
				posY = frame*mainbee.height();
			//	posS = frame3*sweetworld.height();
				mainbee.find('img').css({top:posY*-1});
			//	sweetworld.find('img').css({top:posS*-1});
				frame++;
			//	frame3++;
				
				if(frame >= 30){ 
					frame=0;			
				};
			/*	if( (frame3 > 4) && (frame3 < 8) ){
					frame3 = 8;
				}
				if(frame3 >= 14){
					frame3 = 14;
				};
			*/	enter();
		   }, 80);
		})();  
		beeMainMoving = true;
	}
}
// startMotion
function startMotion(){	
	$('.loadbg').hide();
	if(txtmain == true){
	}else{
		var titCon = $('.anime-main-txt').find('img'),
		frame0 = 0;
		(function enter0(){				
			titTimer0 = setTimeout (function(){
				var posYT, TH;
				TH = $('.anime-main-txt').height();
				posYT = frame0*TH;
				titCon.css({top:posYT*-1});				
				frame0++;
				if(frame0 >= 33){
					frame0=34;
				};
				enter0();
		   }, 65);
		})();  
		txtmain = true;
	}

	beegif();
	balloontween = TweenMax.to($('.mainvisual8'), 1.5, {top:'130px', repeat:-1, yoyo:true, ease:Quad.easeIn});
	cloudtween0 = TweenMax.to($('.mainvisual0'), 4.5, {left:'50%', opacity:1, ease:Power1.easeOut});
	cloudtween1 = TweenMax.to($('.mainvisual1'), 4.5, {left:'50%', opacity:1, ease:Power1.easeOut});
	cloudtween2 = TweenMax.to($('.mainvisual2'), 4, {left:'50%', opacity:1,  ease:Power1.easeOut});
}; 
// slide2 swipe
function noticelist(){
	var mySwiper;
	var mySwiper1;
	var mySwiper2;
	mySwiper = mySwiper1 = mySwiper2 = undefined;
	if (mySwiper == undefined) { 
		mySwiper = new Swiper('.swiper-container.main1-0', {
			mode: 'horizontal',
			slidesPerView: 1,  
			autoplay: 5500,
			loop:true,
			autoplayDisableOnInteraction: false,	
			watchActiveIndex :true,
			pagination: '.swiper-pagination.sp0',
			paginationClickable: true	
		});       
	}; 
	if (mySwiper1 == undefined) { 
		mySwiper1 = new Swiper('.swiper-container.main1-1', {
			mode: 'horizontal',
			slidesPerView: 1,
			autoplay: 5700,
			loop:true,
			autoplayDisableOnInteraction: false,	
			watchActiveIndex :true,
			pagination: '.swiper-pagination.sp1',
			paginationClickable: true	
		});       
	}; 
	if (mySwiper2 == undefined) { 
		mySwiper2 = new Swiper('.swiper-container.main1-2', {
			mode: 'horizontal',
			slidesPerView: 1,
			autoplay: 5900,
			loop:true,
			autoplayDisableOnInteraction: false,         
			watchActiveIndex :true,
			pagination: '.swiper-pagination.sp2',
			paginationClickable: true	
		});       
	}; 
};
// slide3 animations
function beeHoney(){
	frame2 = 0;
	circlemov = false;
//	TweenMax.delayedCall(0.8, circleani, []);
	if( beeMoving == true ){}
	else{
		var honeybee0 = $('.bee'), honeybee1 = $('.honeybee'), honeybee2 = $('.honeypot');
		(function enter1(){
			titTimer1 = setTimeout (function(){
				var posH,
					posB,
					posP;
					
				posH = frame1 * honeybee0.height();
				posB = frame1 * honeybee1.height();
				posP = frame1 * honeybee2.height();			
				honeybee0.find('img').css({top:posH*-1});
				honeybee1.find('img').css({top:posB*-1});
				honeybee2.find('img').css({top:posP*-1});
				frame1++;				
				if(frame1 >= 50){
					frame1=0;			
				};				
				enter1();
		   }, 120);
		})(); 		
		beeMoving = true;
		
	}
};
// slide4 animations
function flybee(){
	if( beeMoving1 == true ){}
	else{
		var small0 = $('.smallbee0'), small1 = $('.smallbee1'), small2 = $('.smallbee2');
		(function enter2(){
			titTimer2 = setTimeout (function(){
				var posBH,
					posBBH;					
				posBH = frame4 * $('.smallbee0').height();		
				posBBH = frame5 * $('.smallbee2').height();			
				small0.find('img').css({top:posBH*-1});
				small1.find('img').css({top:posBH*-1});
				small2.find('img').css({top:posBBH*-1});
				frame4++;
				frame5++;			
				if(frame4 >= 9){
					frame4 = 0;
				};				
				if(frame5 >= 11){
					frame5=0;			
				};				
				enter2();
		   }, 100);
		})(); 	
	
		beeMoving1 = true;
	}
};
// slideNav function
function slideMovto(num){	
	$('.static').removeClass('active');
	$('.static').removeClass('moveDown');
	$('.static').removeClass('moveDownReal');
	$('.static').removeClass('moveUp');
	$('.slideNav-wrap li').removeClass('active');	
	var idx = $('.active.section').attr('id').substr(7,1);
	
	if ( (num > 1) && (idx < num) && ( (num-idx) != 1) ){
		$.fn.fullpage.silentMoveTo(num-1);
		$.fn.fullpage.moveTo(num);
	} else if ( (num > 1) && (idx > num) && ( (idx-num) != 1) ) {
		$.fn.fullpage.silentMoveTo(num+1);
		$.fn.fullpage.moveTo(num);
	} else if (num == 1){
		$.fn.fullpage.silentMoveTo(num);
	
	}else {
		$.fn.fullpage.moveTo(num);
	}
	if( num == 1 ){
		TweenMax.to( $('.staticImg'), 0.3,{css:{top:'0',bottom:''}, ease:Quad.easeInOut});
		$('.staticImg').css({'background-position':'50% 79px'});
	}
	if (num ==2){
		TweenMax.to( $('.staticImg'), 0.3,{css:{top:'',bottom:'480px'}, ease:Quad.easeInOut});
		$('.staticImg').css({'background-position':'50% 100%'});
	}
	if( (num == 4) && (idx !=5) ){
		$('.staticHoney').show();
		$('.staticSnack').hide();	
		$('.staticHoney').css({'left':'0','overflow':'visible'});
		$('.staticSnack').css({'left':'100%','overflow':'hidden'});		
	}
	if( (num == 5) && (idx !=4) ){
		$('.staticHoney').hide();
		$('.staticSnack').show();
		$('.staticHoney').css({'left':'-100%','overflow':'hidden'});
		$('.staticSnack').css({'left':0,'overflow':'visible'});
	}
	if ( (num == 1) || (num == 2) || (num==3) ){	
		TweenMax.to($('.staticBgHoney'), 0.3,{css:{top:'100%'}, ease:Quad.easeInOut});
		$('.staticHoney').css({'left':0});
		$('.staticSnack').css({'left':0});
	}	
	if( (num == 6) ||(num == 7)){
		TweenMax.to($('.staticBgHoney'), 0.3,{css:{top:'-120%'}, ease:Quad.easeInOut});	
		$('.staticHoney').css({'left':0});
		$('.staticSnack').css({'left':0});
	}
	if(num==7){	
		mainsettimeout=true;		
		setTimeout(function(){				
			$.fn.fullpage.setScrollingSpeed(0);
			$.fn.fullpage.silentMoveTo(6);			
			$.fn.fullpage.moveTo(7);
			$.fn.fullpage.setScrollingSpeed(800);
			
		},700);	
		mainsettimeout = false;
	}	
	$('.slideNav-wrap li').eq(num-1).addClass('active');
}
// reset 
function allremove(){
	$('body').removeClass('H834');
	$('body').removeClass('W1024');
	$('body').removeClass('H850');
	$('body').removeClass('H660');
	$('body').removeClass('H870');
	$('body').removeClass('H950');
}

$(window).on('resize',function(){
//	console.log("The thickness of chain");
	$('#section6 .main-footer').css({'height':'0'});
	allremove();
	bodymeasure();
	var CurSlide = $('.section.active').attr('id').substr(7,1);	
	if (CurSlide == 6){	
		mainsettimeout=true;		
		setTimeout(function(){				
			$.fn.fullpage.setScrollingSpeed(0);
			$.fn.fullpage.silentMoveTo(6);			
			$.fn.fullpage.moveTo(7);
			$.fn.fullpage.setScrollingSpeed(800);		
		},700);			
	}   	
	clearTimeout(titTimer1);
	beeMoving = false;
	beeHoney();
});
function init() {	
    window.setTimeout(function(){
        start();
    }, 600);	
}
function start() {	
	/* 
	TweenMax.to( $('.loadingTxt'), .3, {css:{opacity:0}, ease:Quad.easeInOut});
	TweenMax.to( $('#loadingBar'), .4, {css:{opacity:0,'display':'none'}, ease:Quad.easeInOut}); */
	TweenMax.delayedCall(.5, startMotion, []);	
}
// layerMain
function layerMain(){		
	$('.layerMain').css({'display':'block','top':'50%','left':'50%','margin-top':'-295px','margin-left':'-295px','opacity':0,'z-index':'1002'});
	$('.dimmed').css({'width':'100%','height':'100%','display':'block','z-index':'1001'});
	TweenMax.to( $('.layerMain'), 0.3, {css:{'opacity':1}, ease:Quad.easeInOut});
}
function layerMainclose(){
	TweenMax.to( $('.layerMain'), 0.3, {css:{'z-index':0}, ease:Quad.easeInOut});
	$('.layerMain').css({'display':'none','opacity':0});
	$('.dimmed').css({'display':'none','z-index':0});
	$('.dimmed').hide();	
}

// body height, body width, ie version measure..
function bodymeasure(){
	if ( ($(window).width() < 1024) || $(window).height() < 660 ){
		$('body').addClass('shW');		
		$('.honeycont .sub-left .subtxt img').attr('src','/rs/images/main/contents/txt-main2-0-0-0-shW.png');		
	}else{ 
		$('body').removeClass('shW');
	}
	if ( $('body').hasClass('oldie') != true ){
		if( $(window).height() < 660 ){
			$('body').css({'height':'650px'});
		}else{$('body').css({'height':'100%'});}
	}
	var WH = $(window).height(),
		WW = $(window).width();	
	if( (WH < 701) ) { 
		$('body').addClass('H660');		
		$('#section5 .hsContainer').css({'height':'660px','margin-top':'-220px'});
		$('#section6 .hsContent').css({'height':'660px','margin-top':'-235px'});
	}
	if( (WH > 700) && (WH < 835) && (WW > 1025) ){
		$('body').addClass('H834');		
		$('#section5 .hsContainer').css({'height':'720px','margin-top':'-313px'});
		$('#section6 .hsContent').css({'height':'720px','margin-top':'-328px'});
	}
	if( (WW < 1025) && (WH < 701)  ){
		$('body').addClass('W1024'); 
		$('body').addClass('H660');		
		$('#section5 .hsContainer').css({'height':'660px','margin-top':'-220px'});
		$('#section6 .hsContent').css({'height':'660px','margin-top':'-235px'});
	}	
	if( (WW < 1025) && (WH > 700) && (WH < 751) ){ 
		$('body').addClass('W1024'); 
		$('body').addClass('H834');		
		$('#section5 .hsContainer').css({'height':'834px','margin-top':'-303px'});
		$('#section6 .hsContent').css({'height':'834px','margin-top':'-303px'});
	}
	if( (WW < 1025) && (WH > 750) && (WH < 835) ){ 
		$('body').addClass('W1024'); 
		$('body').addClass('H834');		
		$('#section5 .hsContainer').css({'height':'834px','margin-top':'-313px'});
		$('#section6 .hsContent').css({'height':'834px','margin-top':'-328px'});
	}
	if( (WH > 834) && (WH < 854) && (WW > 1025) ){
		$('body').addClass('H850'); 
		$('body').addClass('H834');		
		$('#section5 .hsContainer').css({'height':'834px','margin-top':'-283px'});
		$('#section6 .hsContent').css({'height':'834px','margin-top':'-343px'});
	}
	if( (WH > 853) && (WH < 930) && (WW > 1025) ){
		$('body').addClass('H950'); 
		$('body').addClass('H870');
		
		$('#section5 .hsContainer').css({'height':'950px','margin-top':'-292px'});
		$('#section6 .hsContent').css({'height':'950px','margin-top':'-292px'});	
	}
	if( (WH > 929) && (WH < 951) && (WW > 1025) ) {
		$('body').addClass('H950');

		$('#section5 .hsContainer').css({'height':'950px','margin-top':'-292px'});
		$('#section6 .hsContent').css({'height':'950px','margin-top':'-292px'});			
	}
	if( WH > 849 ){
		$('body').addClass('H849');
		$('#section5 .hsContainer').css({'height':'834px','margin-top':'-283px'});
		$('#section6 .hsContent').css({'height':'834px','margin-top':'-343px'});
	}
}
$(window).load(function() {	
	if($(window).height() > 700 ){ 
		$('.loadbg').css({'width':'2200px','height':'860px','margin-left':'-1100px'});
	}else{
		$('.loadbg').css({'width':'1664px','height':'650px','margin-left':'-832px'});
	}
	$('.loadbg').show();
	init();
});

$(function(){	
	allremove();
	bodymeasure();	
	beeHoney();	
	flybee();	
	$(".btn-gohoneyvillage").mouseenter(function() {			
		$(this).find('img').attr('src', function (i, e) { return e.replace(".png", "-on.png"); });
	}).mouseleave(function() {		
		$(this).find('img').attr('src', function (i, e) { return e.replace("-on.png", ".png"); });
	});
	$(".btn_down").mouseenter(function() {			
		$(this).find('img').attr('src', function (i, e) { return e.replace(".png", "_on.png"); });
	}).mouseleave(function() {		
		$(this).find('img').attr('src', function (i, e) { return e.replace("_on.png", ".png"); });
	});
	// sections...
	$('#fullpage').fullpage({
		'verticalCentered': false,
		anchors: ['haitaiMain', 'company', 'bannerPage', 'honeyStory', 'honeyStory2', 'sweetNews', 'haitaiLink'],
		'css3': true,			
		'menu':'#slideNav',
		'fitToSection': true,
		'scrollOverflow': false,
		'verticalCentered': true,
        resize : true,
		'afterLoad': function(anchorLink, index){				
			switch (index){
				case 1 :					
					$('.staticImg').addClass('active');						
					TweenMax.to($('.staticImg'), 0.2, {css:{top:0,bottom:''}, ease:Quad.easeInOut});
				break;
				case 2 :					
					$('.staticImg').addClass('active');							
					$('.staticInfo').addClass('active');					
					$('#rotate0, #rotate1, #rotate2').addClass('active');
					TweenMax.to($('.staticImg'), 0.8, {delay: -.3,css:{top:'',bottom:'480px'}, ease:Quad.easeInOut});					
				break;
				case 3:
				break;	
				case 4:						
					$('.staticBgHoney .honeycont').show();
					$('.staticSnack').css({'overflow': 'hidden'});
					$('.staticHoney').css({'overflow': 'visible'});
					TweenMax.to($('.staticBgHoney'), .7,{css:{top:0}, ease:Quad.easeInOut});
					TweenMax.to($('.staticBgHoney .snackcont'), 0,{css:{'display':'none',opacity:0}, ease:Quad.easeInOut});			
					TweenMax.to($('.staticBgHoney .honeycont'), 0,{css:{opacity:1}, ease:Quad.easeInOut});	
					TweenMax.to($('.sub-left, .sub-right'), .3,{delay: .3,css:{opacity:1}, ease:Quad.easeInOut});
				break;
				case 5:						
					$('.staticBgHoney .snackcont').show();
					$('.staticHoney').css({'overflow': 'hidden'});
					$('.staticSnack').css({'overflow': 'visible'});
					TweenMax.to($('.staticBgHoney .snackcont'), 0,{css:{opacity:1}, ease:Quad.easeInOut});	
					TweenMax.to($('.staticBgHoney'), .7,{css:{top:0}, ease:Quad.easeInOut});					
					TweenMax.to($('.staticBgHoney .honeycont'), 0,{css:{'display':'none',opacity:0}, ease:Quad.easeInOut});	
					TweenMax.to($('.snack2'), .5,{ delay:-.3, css:{left:'50%'}, ease:Quad.easeInOut});
					TweenMax.to($('.snack1'), .5,{ delay:-.3, css:{left:'50%'}, ease:Quad.easeInOut});
					TweenMax.to($('.snack0'), .6,{ delay:-.3, css:{left:'50%'}, ease:Quad.easeInOut});
					$('.snack').addClass('active');				
					TweenMax.to($('.btn-gohoneyvillage'), 0.3,{delay: .3,css:{opacity:1}, ease:Quad.easeInOut});				
				break;
				case 6:
					TweenMax.to( $('.news-wrap0 .noti0'), .4,{css:{marginTop:'0',opacity:1}, ease:Quad.easeInOut});
					TweenMax.to( $('.tit-newsnoti'), .4,{css:{opacity:1}, ease:Quad.easeInOut});				
					TweenMax.to( $('.tit-newsfacebook'), .4,{css:{top:0,opacity:1}, ease:Quad.easeInOut});
					TweenMax.to( $('.news-wrap0 .noti1'), .4,{css:{marginTop:'0',opacity:1,'filter': 'alpha(opacity=100)'}, ease:Quad.easeInOut});
					TweenMax.to( $('.news-wrap0 .noti2'), .4,{css:{marginTop:'0',opacity:1,'filter': 'alpha(opacity=100)'}, ease:Quad.easeInOut});	
					TweenMax.to( $('.news-wrap1 .noti0'), .35,{css:{marginTop:'0',opacity:1,'filter': 'alpha(opacity=100)'}, ease:Quad.easeInOut});
					TweenMax.to( $('.news-wrap1 .noti1'), .45,{css:{marginTop:'0',opacity:1,'filter': 'alpha(opacity=100)'}, ease:Quad.easeInOut});
					TweenMax.to( $('.news-wrap1 .noti2'), .45,{css:{marginTop:'0',opacity:1,'filter': 'alpha(opacity=100)'}, ease:Quad.easeInOut});	
				break;
				case 7:					
					if ( mainsettimeout == true){
						$('#section6 .main-footer').css({height:0});
					}else{
						if($('body').hasClass('H660') == true ){
							TweenMax.to($('#section6 .main-footer'), .3,{delay:0.7,css:{height:'65px'}, ease:Quad.easeInOut});
						}else{
							TweenMax.to($('#section6 .main-footer'), .3,{delay:0.7,css:{height:'85px'}, ease:Quad.easeInOut});
						}
					}
				break;
				default:				
				break;
			}
			
			if( index != 1){
				$('.staticImg').css({'z-index':0, top:''});
			}
			if( index != 2){
				$('#rotate0, #rotate1, #rotate2').removeClass('active');
				$('#rotate0').css({'margin-left':'-134px'});
				$('#rotate2').css({'margin-left':'148px'});
			}
			if ( (index != 2) && (index != 1) ){				
				$('.staticImg').css({bottom:'',top:'-100%'});
			}
			if(index !=4){
				$('.sub-left, .sub-right').css({opacity:0});			
			}
			if( index != 5){
				$('.btn-gohoneyvillage').css({opacity:0});					
				$('.snack').removeClass('active');	
			}
			if ( (index == 1) || (index == 2)|| (index == 3) || (index == 6) || (index == 7) ){
				$('.staticBgHoney').removeClass('active');
				$('.staticBgHoney').css({'min-height':'500px'});
			}
			if ( (index == 1) || (index == 2)|| (index == 3)){
				$('.staticBgHoney').css({'top':'100%'});
				$('.staticBgHoney').css({opacity:1});	
				$('.staticHoney').css({left:'0'});				
			}
			if( (index == 6) ||(index == 7)){
				$('.staticBgHoney').css({'top':'-150%'});
				$('.staticHoney').css({left:'-100%'});
				$('.staticSnack').css({left:'0'});			
			}
			if( index != 6){			
				$('.news-wrap1 li').css({'margin-top':'5%','opacity':0});
			}
			if( index != 7){				
				$('#section6 .main-footer').css({'height':'0'});
			}	
			if ( $('#main-footer .familysiteon').hasClass('on') ){
				showFamilysite();
			}
		},
		'onLeave': function(index, nextIndex, direction){	
			//	console.log('index'+index+', nextIndex'+nextIndex+', direction'+ direction );
			if( nextIndex == 1){				
				TweenMax.to($('.staticImg'), 0.8,{css:{top:0,bottom:''}, ease:Quad.easeOut});	
				$('.staticImg').css({'background-position':'50% 79px'});
			}
			if( nextIndex == 2 ){
				TweenMax.to($('.staticImg'), 0.8, {delay: -.4,css:{top:'',bottom:'480px'}, ease:Quad.easeInOut});			
				TweenMax.to($('#rotate0, #rotate2'), 0.8, {css:{marginLeft:0}, ease:Quad.easeInOut});
				$('.staticImg').css({'background-position':'50% 79px'});
			}
			if( index == 2 && direction == 'down' ){
				TweenMax.to($('.staticImg'), 0.8, {css:{top:'-100%',bottom:''}, ease:Quad.easeInOut});
			}
			if ( index == 4 && direction == 'up' ) {
				TweenMax.to($('.staticBgHoney'), 0.5,{css:{top:'100%'}, ease:Quad.easeInOut});	
			}			
			if (( nextIndex == 4) ||( nextIndex == 5) ) {	
				$('.staticBgHoney').addClass('active');
				$('.staticBgHoney').css({opacity:1});
				$('.staticBgHoney').css({'min-height':'600px'});			
				TweenMax.to($('.staticBgHoney'), .7,{css:{top:0}, ease:Quad.easeInOut});
			}
			if(nextIndex == 4){
				$('.staticHoney').show();				
				$('.staticHoney').css({top:0});	
				$('.btn-gohoneyvillage').css({opacity:0});	
				$('.staticBgHoney .honeycont').css({opacity:1});				
				
				TweenMax.to($('.staticSnack'), .5,{css:{'opacity':0,left:'100%'}, ease:Quad.easeInOut});
				TweenMax.to($('.staticHoney'), .5,{css:{left:0,'opacity':1}, ease:Quad.easeInOut});				
			}
			if(nextIndex == 5){				
				$('.staticSnack').show();
				$('.staticSnack').css({top:0});
				$('.staticBgHoney .snackcont').css({opacity:1});			
				TweenMax.to($('.sub-left, .sub-right'), .3,{css:{opacity:0}, ease:Quad.easeInOut});
				TweenMax.to($('.staticHoney'), .5,{ css:{'opacity':0,left:'-100%'}, ease:Quad.easeInOut});
				TweenMax.to($('.staticSnack'), .5,{ css:{left:0,'opacity':1}, ease:Quad.easeInOut});
			}
			if ( index == 5 && direction == 'down' ) {
				TweenMax.to($('.staticBgHoney'), 0.5,{css:{top:'-120%'}, ease:Quad.easeInOut});	
			}
			if( nextIndex == 7){
				$('#section6 .main-footer').css({'height':'0'});
			}
			// staticImg = slide1 
			$('.staticImg').toggleClass('active', (index == 2 && direction == 'up' ));
			$('.staticImg').toggleClass('moveDown', nextIndex == 2);
			$('.staticImg').toggleClass('moveDownReal', (index == 2 && direction == 'down') || nextIndex == 3);
			$('.staticImg').toggleClass('moveUp', ( index == 2 && direction == 'up') );			
			// staticBgHoney = bg
			$('.staticBgHoney').toggleClass('active', (index == 3 && direction == 'down' ) || (index == 6 && direction == 'up' ));
			$('.staticBgHoney').toggleClass('moveDownReal', (index == 5 && direction == 'down') || nextIndex == 6 );
			$('.staticBgHoney').toggleClass('moveUp', index == 5 && direction == 'up');	
			$('.staticBgHoney').toggleClass('moveUpReal', index == 4 && direction == 'up');	
			$('.staticBgHoney').toggleClass('moveDown', nextIndex == 5);
			$('.staticBgHoney .honeycont').toggleClass('show',(index == 3 && direction == 'down' ) || (index == 5 && direction == 'up'));
			$('.staticBgHoney .snackcont').toggleClass('show',(index == 4 && direction == 'down' ) || (index == 6 && direction == 'up'));
			// staticHoney = slide4
			$('.staticHoney').toggleClass('active', (index == 3 && direction == 'down' ) || (index == 5 && direction == 'up'));
			$('.staticHoney').toggleClass('moveDown', nextIndex == 5);
			$('.staticHoney').toggleClass('moveUp', index == 5 && direction == 'up');
			//staticSnack = slide5			
			$('.staticSnack').toggleClass('active', (index == 4 && direction == 'down' ) || (index == 6 && direction == 'up'));
			$('.staticSnack').toggleClass('moveDown', nextIndex == 6);
			$('.staticSnack').toggleClass('moveUp', index == 6 && direction == 'up');
		},
		'afterResize':function(anchorLink, index){
			mainsettimeout = false;
			if(index ==7){		
					
				if($('body').hasClass('H660') == true ){
					TweenMax.to($('#section6 .main-footer'), .3,{delay:0.8,css:{height:'65px'}, ease:Quad.easeInOut});
				}else{
					TweenMax.to($('#section6 .main-footer'), .3,{delay:0.8,css:{height:'85px'}, ease:Quad.easeInOut});
				}
			}
		}
	});
	noticelist();

	/* slide6 hover evt */
	$("#section6 .link-wrap a").mouseenter(function() {
		$(this).find('.hover').attr('src', function (i, e) { return e.replace(".png", ".gif"); });
	}).mouseleave(function() {
		$(this).find('.hover').attr('src', function (i, e) { return e.replace(".gif", ".png"); });
	});
});

