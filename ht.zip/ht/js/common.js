var currentNav1 = 0, currentNav2 = -1;
var mousemoveTimer = null;

$(function(){
		var agent = navigator.userAgent.toLowerCase();
		var isIE10 = false;
		/*@cc_on
			if (/^10/.test(@_jscript_version)) {
				isIE10 = true;
			}		
		@*/		
		if (agent.indexOf("Trident") !== -1 && agent.indexOf("rv:11") !== -1){isIE10 = true;}	
		if (isIE10 == true ){$('body').addClass('ie10');}
	if ( (navigator.appName == 'Netscape' && navigator.userAgent.search('Trident') != -1) || (agent.indexOf("msie") != -1) ) {
		$(".fileDiv .btn_search10").attr("tabindex","10");
		$(".fileDiv .btn_search11").attr("tabindex","11");
		
		$(".fileDiv .btn_search14").attr("tabindex","14");
		$(".fileDiv .btn_search16").attr("tabindex","16");
		$(".fileDiv .btn_search18").attr("tabindex","18");
		$(".fileDiv .btn_search20").attr("tabindex","20");
		$(".fileDiv .btn_search22").attr("tabindex","22");
		
		$(".fileDiv .realFile").attr("tabindex","");
	}else{
		$(".fileDiv .btn_search").attr("tabindex","");
		
		$(".fileDiv .realFile10").attr("tabindex","10");
		$(".fileDiv .realFile11").attr("tabindex","11");
		$(".fileDiv .realFile14").attr("tabindex","14");
		$(".fileDiv .realFile16").attr("tabindex","16");
		$(".fileDiv .realFile18").attr("tabindex","18");
		$(".fileDiv .realFile20").attr("tabindex","20");
		$(".fileDiv .realFile22").attr("tabindex","22");
	}

	$("a").attr({"onfocus":"this.blur()"});
	$("a, a img").css({"outline" : "none"});
	$(".btn_addr").attr({"onfocus":""});
	
	$(".btn_addr").focusin(function(){
		$(this).css({border:"1px solid #ed1d85"});
	});

	$(".btn_addr").focusout(function(){
		$(this).css({border:"1px solid #abaaa6"});
	});
  
	var hei = $("#container").height();
	$(".contents").css({"min-height":$(window).height()-170});
	
	$(window).resize(function(){
		$(".contents").css({"min-height":$(window).height()-170});
	});
	var subdepthflag = false;	
	if(location.href.indexOf('introduce') > -1 || location.href.indexOf('faq') > -1) {
	    // 이전
	    var referrer = document.referrer.replace(/^[^:]+:\/\/[^/]+/, '').replace(/#.*/, '');
	        referrer = (referrer != null) ? referrer.split('/') : '';
	        referrer = (referrer.length > 0 ) ? referrer[1] + '/' + referrer[2] : '';
	    //  현재
	    var pathname = location.pathname;
	        pathname = (pathname != null) ? pathname.split('/') : '';
	        pathname = (pathname.length > 0 ) ? pathname[1] + '/' + pathname[2] : '';
		var referU = referrer.split('/')[1], 
			pathU = pathname.split('/')[1];
	    if(referrer != null && referrer != pathname) {	      
	        
	        $('.snb-wrap li .snb-depth2').hide();
	        $('.snb-wrap ul li.subdepth').each(function() {
	            if (subdepthflag == false ){
	                if($(this).hasClass('on')) {
	                    var ele = $(this);			
	                    TweenMax.delayedCall(.2, subdepthslide, [ele]);					
	                }
	            }
	        });
	    }else {
			$('.snb-wrap li .snb-depth2').hide();			
			$('.snb-wrap ul li.subdepth').each(function() {
				if( $(this).hasClass('on') ) {
					TweenMax.to( 
						$(this).find(".snb-depth2"), 0,{css:{'display':'block'} }
					);
				}
			});

		}
	    
		$('.snb-wrap li').click(function(){	
			$('.snb-wrap li .snb-depth2').hide();
			if( $(this).parent().parent().hasClass('snb-wrap') == true){			
				if( $(this).hasClass('negamgt23') ){
					$('.snb-wrap li').removeClass('on');	
					setTimeout(function(){
						$(this).removeClass('negamgt23');
					}, 200);					
				} else {				
					$('.snb-wrap li').removeClass('on');								
				}
				
				setTimeout(function(){
					$(this).addClass('on');
				}, 200);
			}else{
				if($(this).hasClass('on') == true){
					subdepthflag = true;	
				} else{
					subdepthflag = false;	
					$('.snb-wrap li .snb-depth2').removeClass('on');			
					$(this).addClass('on');			
				}					
			}
			
		});
    }else{
		$('.snb-wrap li').click(function(){				
				$('.snb-wrap li').removeClass('on');			
				$(this).addClass('on');					
		});
	}
	$('.subNav_wrap a').click(function(){
		$('.bg-subNav').hide();
		$('.subNav').hide();
		$('.img-subNav').hide();
		$('.img-subNav').removeClass('onSubnav');
		$("#main-header").removeClass('mouseon');
	});
		
	
	
	// 체크박스
	$(".chk_wrap").click(function(){
		if($(".chk_wrap .chk").hasClass("on")){
			$(".chk_wrap .chk").removeClass("on");
		}else{
			$(".chk_wrap .chk").addClass("on");
		}
	});

	$(".chkBx_wrap").click(function(){
		if($(".chkBx_wrap .chkBx").hasClass("on")){
			$(".chkBx_wrap .chkBx").removeClass("on");
		}else{
			$(".chkBx_wrap .chkBx").addClass("on");
		}
	});
	
	//해외 버튼
	$(".chk_address").click(function(){
		if($(".chk_address .chkBx").hasClass("on")){
			$(".chk_address .chkBx").removeClass("on");
			
			$("#searchAddressBtn").removeClass("disabled");
			$("#zipcode").attr("disabled",false);
			$("#address").attr("disabled",false);
			$("#address2").attr("disabled",false);
			
			$("#faqmsg").text("");
		}else{
			$(".chk_address .chkBx").addClass("on");
			
			$("#searchAddressBtn").addClass("disabled");
			$("#zipcode").attr("disabled",true);
			$("#address").attr("disabled",true);
			$("#address2").attr("disabled",true);
			
			$("#zipcode").val("");
			$("#address").val("");
			$("#address2").val("");
			
			$("#faqmsg").text("* 해외에 거주하시는 분께서는 주소를 아래쪽 내용란에 같이 입력해주시기 바랍니다!");
		}
	});

	//셀렉트
	$(".selectBox").click(function(){
		$(".dropDown").slideDown();
	});

	$(".dropDown li").click(function(){
		$(".dropDown").slideUp();
		var option = $(".dropDown li:eq("+$(this).index()+")");
		$(".dropDown li").removeClass("active");
		option.addClass("active");
		$(".selectBox").html(option.text());
	});

	var selectBox2Flag = false;

	$(".selectBox2").click(function(){
		$(this).parents("td").css({"z-index":"20001"});
		
		if(selectBox2Flag == false){
			$(".dropDown2").slideDown();
			$(".selectBox2").css({border:"1px solid #ed1d85"});
			$(".dropDown2").css({"border-top":0});
			selectBox2Flag = true;
		}else{
			selectBox2Flag = false;
			$(".dropDown2").slideUp();
			setTimeout(function(){
				$(".selectBox2").css({border:"1px solid #cccccc"});
			},500);
		}

	});

	$(".dropDown2 li").click(function(){
		selectBox2Flag = false;
		$(".dropDown2").slideUp();
		setTimeout(function(){
			$(".selectBox2").css({border:"1px solid #cccccc"});
		},500);		
		var option = $(".dropDown2 li:eq("+$(this).index()+")");
		$(".dropDown2 li").removeClass("active");
		option.addClass("active");
		$(".selectBox2").html(option.text());
	});

	var selectBox3Flag = false;
	$(".selectBox3").click(function(){
		$(this).parents("td").css({"z-index":"20000"});
		
		if(selectBox3Flag == false){
			$(".dropDown3").slideDown();
			$(".selectBox3").css({border:"1px solid #ed1d85"});
			$(".dropDown3").css({"border-top":0});
			selectBox3Flag = true;
		}else{
			$(".dropDown3").slideUp();
			setTimeout(function(){
				$(".selectBox3").css({border:"1px solid #cccccc"});
			},500);
			selectBox3Flag = false;
		}
	});

	$(".dropDown3 li").click(function(){
		selectBox3Flag = false;
		$(".dropDown3").slideUp();
		setTimeout(function(){
			$(".selectBox3").css({border:"1px solid #cccccc"});
		},500);		
		
		var option = $(".dropDown3 li:eq("+$(this).index()+")");
		$(".dropDown3 li").removeClass("active");
		option.addClass("active");
		
		if(option.text() == "직접입력") {
			var html = '';
			html +='<label for="tel2" class="hidden">연락처</label>';
			html +='<input type="text" name="tel2" id="tel2" class="ipt_name number" maxlength="30" >';
			
			$("#phonechange").empty().append(html);
		} else {
			var html = '';
			html +='<span>-</span>';
			html +='<label for="tel2" class="hidden">연락처</label>';
			html +='<input type="text" name="tel2" id="tel2" class="ipt_phone number" maxlength="4" tabindex="6">';
			html +='<span>-</span>';
			html +='<label for="tel3" class="hidden">연락처</label>';
			html +='<input type="text" name="tel3" id="tel3" class="ipt_phone number" maxlength="4" tabindex="7">';                              

			$("#phonechange").empty().append(html);
		}
		$(".selectBox3").html(option.text());
	});

	var selectBox4Flag = false;
	$(".selectBox4").click(function(){
		$(this).parents("td").css({"z-index":"20000"});
		
		if(selectBox4Flag == false){
			$(".dropDown4").slideDown();
			$(".selectBox4").css({border:"1px solid #ed1d85"});
			$(".dropDown4").css({"border-top":0});
			selectBox4Flag = true;
		}else{
			selectBox4Flag = false;
			$(".dropDown4").slideUp();

			setTimeout(function(){
				$(".selectBox4").css({border:"1px solid #cccccc"});
			},500);
		}

	});

	$(".dropDown4 li").click(function(){
		selectBox4Flag = false;
		if($(this).index() == 0){
			$(".btn_customer, .prod_text").show();
		}else{
			$(".btn_customer, .prod_text").hide();
		}
		$(".dropDown4").slideUp();
		setTimeout(function(){
			$(".selectBox4").css({border:"1px solid #cccccc"});
		},500);		
		var option = $(".dropDown4 li:eq("+$(this).index()+")");
		$(".dropDown4 li").removeClass("active");
		option.addClass("active");

		$(".selectBox4").html(option.text());
	});


	$(".input_wrap .ipt").click(function(){
		$(".dropDown").slideUp();
	});

	$(".declare_content input, .input_wrap input").click(function(){
		$(".dropDown2, .dropDown3, .dropDown4").slideUp();

		setTimeout(function(){
			$(".selectBox2, .selectBox3, .selectBox4").css({border:"1px solid #cccccc"});
		},500);
	});


	
	$(".selectBox2,.selectBox3,.selectBox4").focusin(function(){
		$(this).css({border:"1px solid #ed1d85"});
	});

	$(".selectBox2,.selectBox3,.selectBox4").focusout(function(){
		$(this).css({border:"1px solid #cccccc"});
	});



	// gnb s
	$("#main-header .header-nav").mouseenter(function() {	
		TweenLite.to($(this).find('.gnb-border'), 0.3, {css:{width:'100%'}});    
		$(this).find('span img').attr('src', function (i, e) { return e.replace(".png", "_on.png"); });
		var Nidx = $(this).parent('li').index();		
		currentNav1 = Nidx;
		navBorder(Nidx,0);
	}).mouseleave(function() {
		TweenLite.to($(this).find('.gnb-border'), 0.3, {css:{width:'0'}});   
		$(this).find('span img').attr('src', function (i, e) { return e.replace("_on.png", ".png"); });			
	});
	
	$(".navright li a").mouseenter(function() {			
		$(this).find('img').attr('src', function (i, e) { return e.replace(".png", "_on.png"); });
	}).mouseleave(function() {		
		$(this).find('img').attr('src', function (i, e) { return e.replace("_on.png", ".png"); });
	});
	

	$("#container, #fullpage, .static").mouseenter(function(){
		$("#main-header").removeClass('mouseon'); 
		closeNav();	
	}).mouseleave(function(){
	
	});
	
	$('.bg-subNav').mouseenter(function() {	
		$("#main-header").addClass('mouseon'); 
	}).mouseleave(function(){
	});

	$('.subNav').mouseenter(function() {	
		$("#main-header").addClass('mouseon'); 
		$('.subNav').addClass('mouseon');

		var Nidx = $(this).parent('li').index();
		currentNav2 = Nidx;
		navBorder(Nidx,0);
	}).mouseleave(function(){
		$('.subNav').removeClass('mouseon');
		$("#main-header").removeClass('mouseon'); 
	});

	// gnb e

	//tabNav on hover
	$('.tabNav li a').click(function(){
		$('.tabNav li').removeClass('on');		
		$(this).parent().addClass('on');		
	});

	//footer 
	$('.main-footer').click(function(){
		if ( $('#main-footer .familysiteon').hasClass('on') ){
				showFamilysite();
			}
	});
	$('.familysiteon').click(function(){
		if ( $('#main-footer .familysiteon').hasClass('on') ){
			showFamilysite();
		}
	});

});
window.onscroll=function(){ 
	closeNav(); 
	if ( $('.familysiteon').hasClass('on') ){
		showFamilysite();
	}
};
function subdepthslide(ele){
	ele.find(".snb-depth2").slideDown();
}
function showFamilysite(){
	$('.familysiteon').toggle();
	$('.familysiteon').toggleClass('on');
}

function navBorder(idx,num){	
	$("#main-header").addClass('mouseon');
	$('.img-subNav').removeClass('onSubnav');
	$('.bg-subNav').slideDown();
	setTimeout(function(){
		$('.subNav').fadeIn();
		$('.img-subNav').fadeIn();
	},200);	

TweenLite.to($(".imgSubNav"), 0.3, { css :{ opacity: 0}});
	TweenLite.to($(".imgSubNav"+idx), 1, { css :{ opacity: 1,delay:0.3}, ease:Circ.easeOut});
	
	$('.img-subNav').addClass('onSubnav');
	$('.hearder-nav').find('span img').attr('src', function (i, e) { return e.replace("_on.png", ".png"); });
	$('.hearder-nav').eq(idx).find('span img').attr('src', function (i, e) { return e.replace(".png", "_on.png"); });

	if(currentNav1 != currentNav2){
				
		for(var subNavidx = 0;subNavidx<10;subNavidx++){
			$('.onSubnav img').stop().delay(subNavidx * 8).animate({top:subNavidx*-258},1);
			
			//TweenLite.to($('.onSubnav img'), 0, { css :{ 'top': subNavidx*-258}, delay:subNavidx * 0.08});
		}
	
		if(subNavidx >=9){subNavidx ==9}
		
		currentNav1 = idx;
		currentNav2 = idx;
	}

}
function closeNav(){	
	
	$('.bg-subNav').slideUp(300);
	$('.subNav').hide();
	$('.img-subNav').hide();

	$('.img-subNav').removeClass('onSubnav');
	$("#main-header").removeClass('mouseon');
		

	
}


function searchfocus(num){
	if (num ==0){
		$('.i_text4').css({'background':'url("/rs/images/main/btn/gnb7_on.png") 0 0 no-repeat'});
	}else{
		$('.i_text4').css({'background':'url("/rs/images/main/btn/gnb7_v.png") 0 0 no-repeat'});
	}
}

function searchfocus2(num){
	if (num ==0){
		$('.i_text4').css({'background':'url("/rs/images/sub/btn/gnb7_on.png") 0 0 no-repeat'});
	}else{
		$('.i_text4').css({'background':'url("/rs/images/sub/btn/gnb7_v.png") 0 0 no-repeat'});
	}
}

	
function flashVerChk() {

}

